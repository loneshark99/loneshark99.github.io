package com.example;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DataStreamJob {

	private static final Logger LOG = LoggerFactory.getLogger(DataStreamJob.class);

	public static void main(String[] args) throws Exception {
		// Create the environment (local or cluster context)
		final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

		// 1. Source: Create a simple data stream
		DataStream<String> text = env.fromElements("flink", "streaming", "starter", "tutorial");

		// 2. Transformation: Map to uppercase
		DataStream<String> upperCase = text.map(new MapFunction<String, String>() {
			@Override
			public String map(String value) {
				LOG.info("Processing element: {}", value);
				return value.toUpperCase();
			}
		});

		// 3. Sink: Print to standard output
		upperCase.print();

		// 4. Execution: Trigger the job graph
		LOG.info("Starting Flink Job");
		env.execute("Flink 1.19 Java Starter");
	}
}
