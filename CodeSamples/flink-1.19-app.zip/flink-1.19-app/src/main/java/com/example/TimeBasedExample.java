package com.example;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class TimeBasedExample {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> streamSource =  env.socketTextStream("localhost", 4567);
        DataStream<Tuple2<String, Integer>> dataStream = streamSource.map(line -> {
            String[] elements = line.split(",");
            return Tuple2.of(elements[0], Integer.valueOf(elements[1]));
        }, Types.TUPLE(Types.STRING, Types.INT));


        dataStream.keyBy(item -> item.f0).process(new TestKeyedProcessFunction());

        dataStream.print();
        env.execute("Time Based Example");
    }
}
