package com.example;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;

public class TestKeyedProcessFunction extends KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Integer>> {

    private Logger LOG = org.slf4j.LoggerFactory.getLogger(TestKeyedProcessFunction.class);
    private ValueState<Integer> valueState;
    private ValueState<Long> timestampState;

    public TestKeyedProcessFunction() {
        super();
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        LOG.info("Open called");
        this.valueState = this.getRuntimeContext().getState(new ValueStateDescriptor<>("valueState", Types.INT));
        this.timestampState = this.getRuntimeContext().getState(new ValueStateDescriptor<>("timestampState", Types.LONG));
        LOG.info("Open Ended");
    }

    @Override
    public void processElement(Tuple2<String, Integer> value, KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Integer>>.Context context, Collector<Tuple2<String, Integer>> collector) throws Exception {
        if (valueState.value() == null) {
            valueState.update(0);
        }

        if (timestampState.value() == null) {
            LOG.info("Registering timer for key = " + context.getCurrentKey());
            timestampState.update(context.timerService().currentProcessingTime() + 1_000 * 60L);
            context.timerService().registerProcessingTimeTimer(timestampState.value());
            LOG.info("Timer Registered for key = " + context.getCurrentKey() + " at" + timestampState.value());
        }

        valueState.update(valueState.value() + value.f1);
        LOG.info("Value updated for Key = " + context.getCurrentKey() + " to " + valueState.value());
    }

    @Override
    public void onTimer(long timestamp, KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Integer>>.OnTimerContext ctx, Collector<Tuple2<String, Integer>> out) throws Exception {
        LOG.info("Timer fired for key = " + ctx.getCurrentKey() + " at" + timestamp);
        out.collect(Tuple2.of(ctx.getCurrentKey(), valueState.value()));
        timestampState.clear();
        LOG.info("Timer reset for key = " + ctx.getCurrentKey());
    }
}